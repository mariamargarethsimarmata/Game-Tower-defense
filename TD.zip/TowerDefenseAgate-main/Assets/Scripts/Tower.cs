﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower : MonoBehaviour
{
    public Vector2? PlacePosition { get; private set; }
    //component tower
    [SerializeField] private SpriteRenderer _towerPlace;
    [SerializeField] private SpriteRenderer _towerHead;

    //properti tower
    [SerializeField] private int _shootPower = 1;
    [SerializeField] private float _shootDistance = 1f;
    [SerializeField] private float _shootDelay = 5f;
    [SerializeField] private float _bulletSpeed = 1f;
    [SerializeField] private float _bulletSplashRadius = 0f;
    [SerializeField] private Bullet _bulletPrefab;

    private float _runningShootDelay;
    private Enemy _targetEnemy;
    private Quaternion _targetRotation;

    //mengecek musuh terdekat
    public void CheckNearestEnemy(List<Enemy> enemies)
    {
        if (_targetEnemy != null)
        {
            if(!_targetEnemy.gameObject.activeSelf||Vector3.Distance(transform.position,_targetEnemy.transform.position)>_shootDistance)
            {
                _targetEnemy = null;//target tidak ada
            }
            else
            {
                return;//jika ada cek ke fungsi awal
            }

        }
        float nearestDistance = Mathf.Infinity;
        Enemy nearestEnemy = null;
        foreach(Enemy enemy in enemies)
        {
            float distance = Vector3.Distance(transform.position, enemy.transform.position);
            if (distance > _shootDistance)
            {
                continue;//jika jarak musuh lebih besar dari jarak tembak maka lanjut ke fungsi berikutnya
            }
            if (distance < nearestDistance)
            {
                nearestDistance = distance;//jarak terdekat ubah ke jarak saat ini
                nearestEnemy = enemy;//jarak enemy ubah ke posisi enemy
            }
        }
        _targetEnemy = nearestEnemy;
    }
    //menembak musuh disimpan sebagai target
    public void ShootTarget()
    {
        if (_targetEnemy == null)
        {
            return;
        }
        _runningShootDelay -= Time.unscaledDeltaTime;
        if (_runningShootDelay <= 0f)
        {
            bool headHasAimed = Mathf.Abs(_towerHead.transform.rotation.eulerAngles.z - _targetRotation.eulerAngles.z) < 10f;
            if (!headHasAimed)
            {
                return;
            }
            Bullet bullet = LevelManager.instance.GetBulletFromPool(_bulletPrefab);
            bullet.transform.position = transform.position;
            bullet.SetProperties(_shootPower, _bulletSpeed, _bulletSplashRadius);
            bullet.SetTargetEnemy(_targetEnemy);
            bullet.gameObject.SetActive(true);
            _runningShootDelay = _shootDelay;
        }
    }
    //membuat tower melihat ke arah musuh
    public void SeekTarget()
    {
        if (_targetEnemy == null)
        {
            return;
        }
        Vector3 direction = _targetEnemy.transform.position - transform.position;
        float targetAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        _targetRotation = Quaternion.Euler(new Vector3(0f, 0f, targetAngle - 90f));
        _towerHead.transform.rotation = Quaternion.RotateTowards(_towerHead.transform.rotation, _targetRotation, Time.deltaTime * 180f);

    }
    //fungsi mengambil sprite tower head
    public Sprite GetTowerHeadIcon()
    {
        return _towerHead.sprite;
    }
    public void SetPlacePosition(Vector2? newPosition)
    {
        PlacePosition = newPosition;
    }
    public void LockPlacement()
    {
        transform.position = (Vector2)PlacePosition;
    }
    public void ToggleOrderInLayer(bool toFront)
    {
        int orderInLayer = toFront ? 2 : 0;
        _towerPlace.sortingOrder = orderInLayer;
        _towerHead.sortingOrder = orderInLayer;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
